import React from "react";
import { FaBell } from "react-icons/fa";

const Topbar = () => {
  const topbarStyle = {
    backgroundColor: "#f5f5f5",
    padding: "10px 20px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    borderBottom: "1px solid #ccc"
  };

  const inputStyle = {
    padding: "8px 12px",
    borderRadius: "4px",
    border: "1px solid #ccc",
    width: "250px"
  };

  return (
    <div style={topbarStyle}>
      <input type="text" placeholder="Search..." style={inputStyle} />
      <FaBell size={20} />
    </div>
  );
};

export default Topbar;