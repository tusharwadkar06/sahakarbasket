import React from "react";
import { FaHome, FaTachometerAlt, FaBox, FaChartLine, FaCalendarAlt, FaHistory, FaEnvelope, FaBell, FaCog, FaSignOutAlt } from "react-icons/fa";

const Sidebar = () => {
  const sidebarStyle = {
    width: "220px",
    backgroundColor: "#ffffff",
    padding: "20px",
    height: "90vh",
    borderRight: "1px solid #ccc",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between"
  };

  const menuItemStyle = {
    display: "flex",
    alignItems: "center",
    marginBottom: "10px",
    position: "relative"
  };

  const iconStyle = { marginRight: "10px" };

  const badgeStyle = {
    position: "absolute",
    right: 0,
    background: "red",
    borderRadius: "50%",
    color: "#fff",
    fontSize: "10px",
    padding: "2px 6px"
  };

  return (
    <div style={sidebarStyle}>
      <div>
        <h2 style={{ fontSize: "20px", marginBottom: "30px" }}>Sahakar Basket</h2>
        {[
          { icon: <FaHome />, label: "Home" },
          { icon: <FaTachometerAlt />, label: "Dashboard" },
          { icon: <FaBox />, label: "Products" },
          { icon: <FaChartLine />, label: "Analytics" },
          { icon: <FaCalendarAlt />, label: "Schedules", badge: 2 },
          { icon: <FaHistory />, label: "History" },
        ].map((item, index) => (
          <div key={index} style={menuItemStyle}>
            <div style={iconStyle}>{item.icon}</div>
            <span>{item.label}</span>
            {item.badge && <span style={badgeStyle}>{item.badge}</span>}
          </div>
        ))}

        <hr style={{ margin: "20px 0" }} />

        {[
          { icon: <FaEnvelope />, label: "Messages", badge: 2 },
          { icon: <FaBell />, label: "Notifications", badge: 2 },
          { icon: <FaCog />, label: "Settings" },
          { icon: <FaSignOutAlt />, label: "Logout" },
        ].map((item, index) => (
          <div key={index} style={menuItemStyle}>
            <div style={iconStyle}>{item.icon}</div>
            <span>{item.label}</span>
            {item.badge && <span style={badgeStyle}>{item.badge}</span>}
          </div>
        ))}
      </div>

      <div style={{ fontSize: "12px", color: "#888" }}>
        <img src="https://i.pravatar.cc/30" alt="User" style={{ borderRadius: "50%", marginRight: "10px" }} />
        <div>Michael Smith<br /><span style={{ fontSize: "11px" }}>michaelsmith12@gmail.com</span></div>
      </div>
    </div>
  );
};

export default Sidebar;