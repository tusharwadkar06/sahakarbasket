import React from "react";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";

const layoutStyle = {
  display: "flex",
  height: "100vh"
};

const mainContentStyle = {
  flex: 1,
  display: "flex",
  flexDirection: "column"
};

const contentWrapperStyle = {
  flex: 1,
  padding: "20px",
  backgroundColor: "#f9fafb",
  overflowY: "auto"
};

export default function Layout({ children }) {
  return (
    <div style={layoutStyle}>
      <Sidebar />
      <div style={mainContentStyle}>
        <Topbar />
        <div style={contentWrapperStyle}>{children}</div>
      </div>
    </div>
  );
}