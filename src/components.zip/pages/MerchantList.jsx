import React from "react";

const merchants = [
  { name: "Takeaway", contact: "91+ 7894561231", category: "Goods", status: "Active" },
  { name: "Takeaway", contact: "91+ 7894561231", category: "Goods", status: "Active" },
  { name: "Takeaway", contact: "91+ 7894561231", category: "Goods", status: "Active" },
  { name: "Takeaway", contact: "91+ 7894561231", category: "Goods", status: "Active" },
  { name: "Takeaway", contact: "91+ 7894561231", category: "Goods", status: "Active" },
  { name: "Takeaway", contact: "91+ 7894561231", category: "Services", status: "Inactive" },
  { name: "Takeaway", contact: "91+ 7894561231", category: "Services", status: "Inactive" },
  { name: "Takeaway", contact: "91+ 7894561231", category: "Services", status: "Inactive" },
  { name: "Takeaway", contact: "91+ 7894561231", category: "Services", status: "Inactive" },
  { name: "Takeaway", contact: "91+ 7894561231", category: "Services", status: "Inactive" },
  { name: "Takeaway", contact: "91+ 7894561231", category: "Services", status: "Inactive" },
];

const MerchantList = () => {
  return (
    <div className="main-page">
      {/* Breadcrumb */}
      <div className="breadcrumb">
        Home &gt; Merchant List &gt; <span className="highlight">Merchant Info</span>
      </div>

      <div className="merchant-container">
        {/* Toolbar */}
        <div className="toolbar">
          <h2>Merchant List</h2>
          <div className="toolbar-buttons">
            <input type="text" className="search-input" placeholder="🔍 Search" />
            <button className="btn">🔽 Filter</button>
            <button className="btn">📤 Export</button>
            <button className="btn btn-primary">Add User</button>
            <button className="btn">🔄</button>
          </div>
        </div>

        {/* Merchant Table */}
        <table className="merchant-table">
          <thead>
            <tr>
              <th><input type="checkbox" /></th>
              <th>Merchant Name</th>
              <th>📞 Contact</th>
              <th>📋 Category</th>
              <th>🟢 Status</th>
              <th>⚙️ Action</th>
            </tr>
          </thead>
          <tbody>
            {merchants.map((m, index) => (
              <tr key={index}>
                <td><input type="checkbox" /></td>
                <td>{m.name}</td>
                <td>{m.contact}</td>
                <td>{m.category}</td>
                <td>
                  <span className={`status ${m.status === "Active" ? "active" : "inactive"}`}>
                    ● {m.status}
                  </span>
                </td>
                <td>
                  <button className="btn-sm">✏️ Edit</button>
                  <button className="btn-sm">👁️ View</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Bottom Controls */}
        <div className="bottom-controls">
          <select>
            <option>10</option>
            <option>20</option>
            <option>50</option>
          </select>
          <div className="pagination">
            Page 1 &nbsp;&nbsp; &lt;&lt; Previous &nbsp;&nbsp; Next &gt;&gt;
          </div>
        </div>
      </div>

      {/* Inline Styles (CSS-in-JS via style tag for standalone use) */}
      <style>{`
        .main-page {
          padding: 5px;
          font-family: Arial, sans-serif;
          background-color:rgb(245, 241, 241);
          min-height: 100vh;
        }

        .breadcrumb {
          margin-bottom: 15px;
          font-size: 14px;
          color: #555;
        }

        .breadcrumb .highlight {
          color: #007bff;
          font-weight: 500;
        }

        .merchant-container {
          background-color: #fff;
          padding: 15px;
          border-radius: 12px;
          box-shadow: 0 0 8px rgba(0, 0, 0, 0.05);
        }

        .toolbar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 10px;
        }

        .toolbar-buttons {
          display: flex;
          gap: 10px;
          align-items: center;
        }

        .search-input {
          padding: 6px 10px;
          border: 1px solid #ccc;
          border-radius: 5px;
        }

        .btn {
          padding: 6px 10px;
          border: 1px solid #ccc;
          background-color: #fff;
          border-radius: 5px;
          cursor: pointer;
        }

        .btn-primary {
          background-color: #4f46e5;
          color: #fff;
          border: none;
        }

        .merchant-table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 10px;
        }

        .merchant-table thead tr {
          background-color: #add9ff;
        }

        .merchant-table th,
        .merchant-table td {
          padding: 8px;
          border-bottom: 1px solid #ddd;
          text-align: left;
        }

        .status {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 2px 16px 2px 10px;
          border-radius: 10px;
          border: 1px solid #bbb;
          font-size: 13px;
        }

        .status.active {
          color: green;
          font-weight: 600;
        }

        .status.inactive {
          color: red;
          font-weight: 600;
        }

        .btn-sm {
          margin-right: 5px;
          padding: 5px 7px;
          font-size: 12px;
          border: 1px solid #ddd;
          border-radius: 4px;
          background-color: #f9f9f9;
        }

        .bottom-controls {
          margin-top: 20px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .pagination {
          font-size: 14px;
          color: #333;
        }
      `}</style>
    </div>
  );
};

export default MerchantList;
