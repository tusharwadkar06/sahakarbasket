import React from 'react';
import branch from '../assets/images/branch.png'; 
import buyer from '../assets/images/buyer.png';  
import discount from '../assets/images/discount.png'; 
import report from '../assets/images/report.png'; 
import user from '../assets/images/user.png'; 
import merchant from '../assets/images/merchant.png';

const cardData = [
  { title: 'Merchant', imgSrc: merchant },
  { title: 'Buyer', imgSrc: buyer },
  { title: 'Discount', imgSrc: discount },
  { title: 'Report & Analytics', imgSrc: report },
  { title: 'Branch', imgSrc: branch },
  { title: 'User & Role Management', imgSrc: user },
];

const MainContent = () => {
  return (
    <div style={{ padding: 20, flex: 1, backgroundColor: '#f9fafb', display: 'flex', flexWrap: 'wrap', gap: 20 }}>
      {cardData.map(({ title, imgSrc }) => (
        <div
          key={title}
          style={{
            flex: '1 1 calc(33.333% - 20px)',
            background: 'white',
            borderRadius: 10,
            boxShadow: '0 0 8px rgb(0 0 0 / 0.1)',
            padding: 20,
            textAlign: 'center',
            cursor: 'pointer',
            minWidth: 260,
          }}
        >
          <img src={imgSrc} alt={title} style={{ maxWidth: 100, marginBottom: 12 }} />
          <div style={{ fontWeight: '600', fontSize: 18 }}>{title}</div>
        </div>
      ))}
    </div>
  );
};

export default MainContent;
